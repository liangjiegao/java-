create
    definer = root@`%` procedure insertFile()
BEGIN
DECLARE i INT;
DECLARE j INT;
DECLARE filename VARCHAR(100);
DECLARE parent VARCHAR(10);
DECLARE file_path VARCHAR(200);
DECLARE link_id INT;
DECLARE TYPE VARCHAR(20);
DECLARE size INT;
DECLARE DATETIME DATETIME;
DECLARE user_id INT;
DECLARE char_str VARCHAR(100) DEFAULT 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
SET i = 0;
SET parent = 'user';
SET file_path = '';
SET link_id = 10015;
SET TYPE = 'dir';
SET size = 0;
SET user_id = 10015;
WHILE i < 10000 DO
SET j = 0;
SET filename = '';
WHILE j < 10 DO
SET filename = CONCAT(filename, SUBSTRING(char_str, FLOOR(1+RAND()*62), 1));
SET j = j + 1;
END WHILE;
SET DATETIME = NOW();
INSERT INTO FILE VALUES(NULL, filename, parent, file_path, link_id, TYPE, size, DATETIME, user_id);
SET i = i+1;
END WHILE;
END;

